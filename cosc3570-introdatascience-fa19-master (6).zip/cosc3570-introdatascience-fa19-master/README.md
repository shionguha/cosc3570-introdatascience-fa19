# cosc3570-introdatascience-fa19
This is the official respository for COSC/MATH 3570 at Marquette University for Fall 2019. All course resources and project code will be uploaded here. 
