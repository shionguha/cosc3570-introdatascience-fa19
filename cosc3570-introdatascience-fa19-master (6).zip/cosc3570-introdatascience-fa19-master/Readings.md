# September 3
1. Seltzer, William, and Margo Anderson. “The Dark Side of Numbers: The Role of Population Data Systems in Human Rights Abuses.” Social Research 68.2 (2001): 481-513.  
Link: https://www.jstor.org/stable/pdf/40971467.pdf

2. Latonero, Mark. “An App to Save Syria’s Lost Generation?” Foreign Affairs, 2016 May 23.  
Link: https://www.foreignaffairs.com/articles/syria/2016-05-23/app-save-syrias-lost-generation

# September 5
1. Rich, Michael L. “Should We Make Crime Impossible?” Harvard Journal of Law and Public Policy 36 (2013): 795-848. 
Link: https://www.harvard-jlpp.com/wp-content/uploads/sites/21/2013/04/36_2_795_Rich.pdf 

2. NY Times. 2016. Backlash in Wisconsin against using data to foretell defendants future.
Link: https://www.nytimes.com/2016/06/23/us/backlash-in-wisconsin-against-using-data-to-foretell-defendants-futures.html





